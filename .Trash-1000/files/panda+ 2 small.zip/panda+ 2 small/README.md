## Operating systems project UniBo 2021/2022

A simple operating system for the MIPS architecture

---


## Makefile:

In the makefile directory run:

- `make` to compile the code
- `make clean` to delete the compiled object files  
--- 
## How to run Test
- Run `make` in the makefile directory
- Open `umps3` software
- Create a new machine configuration
- Power on the machine and then click "continue"
- Look in the terminal of the machine the tests results
