#ifndef PANDOS_INTERRUPT_H
#define PANDOS_INTERRUPT_H

extern void interrupt_handler();
extern void pass_up_or_die(int code);

#endif