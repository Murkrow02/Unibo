#ifndef PANDOS_P2TEST_H
#define PANDOS_P2TEST_H

extern void test();
extern void uTLB_RefillHandler();

#endif
