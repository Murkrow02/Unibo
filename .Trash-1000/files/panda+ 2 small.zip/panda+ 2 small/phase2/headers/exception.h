#ifndef PANDOS_EXCEPTION_H
#define PANDOS_EXCEPTION_H

extern void exception_hanlder();

#endif